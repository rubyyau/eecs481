package com.example.mygame;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_main);

	    GridView gridview = (GridView) findViewById(R.id.gridview);
	    final imageAdapter ImageAdapter = new imageAdapter(this);
	    gridview.setAdapter(ImageAdapter);
	    
	    gridview.setOnItemClickListener(new OnItemClickListener() {
	    	
	        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
	        	int whiteSpace = whiteSpaceDetected(position);
	        	if (whiteSpace != -1){
	        		swap(position, whiteSpace);
	        	}
	        	else {
	        		Toast.makeText(MainActivity.this, "invalid choice", Toast.LENGTH_SHORT).show();
	        	}
	        	
	        	//CHECK TO SEE IF ITS GAME IS COMPLETED
	        	if (checkWin() == 1) {
	        		Toast.makeText(MainActivity.this, "YOU WON!", Toast.LENGTH_LONG).show();
	        	}
	        	
	        }
	    });
	    
	    Button resetButton = (Button) findViewById(R.id.button1);
		resetButton.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					GridView gridview = (GridView) findViewById(R.id.gridview);
		    		gridview.setAdapter(ImageAdapter);
		    		
				}
		});
	    
	    
	}
	


	protected int checkWin(){
		GridView gridview = (GridView) findViewById(R.id.gridview);
		ImageView pos0 = (ImageView) gridview.getChildAt(0);
		ImageView pos1 = (ImageView) gridview.getChildAt(1);
		ImageView pos2 = (ImageView) gridview.getChildAt(2);
		ImageView pos3 = (ImageView) gridview.getChildAt(3);
		ImageView pos4 = (ImageView) gridview.getChildAt(4);
		ImageView pos5 = (ImageView) gridview.getChildAt(5);
		ImageView pos6 = (ImageView) gridview.getChildAt(6);
		ImageView pos7 = (ImageView) gridview.getChildAt(7);
		ImageView pos8 = (ImageView) gridview.getChildAt(8);		
		
		if(!pos0.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece1).getConstantState())){
			return -1; 
		}
		if(!pos1.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece2).getConstantState())){
			return -1; 
		}
		if(!pos2.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece3).getConstantState())){
			return -1; 
		}
		if(!pos3.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece4).getConstantState())){
			return -1; 
		}
		if(!pos4.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece5).getConstantState())){
			return -1; 
		}
		if(!pos5.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece6).getConstantState())){
			return -1; 
		}
		if(!pos6.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece7).getConstantState())){
			return -1; 
		}
		if(!pos7.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece8).getConstantState())){
			return -1; 
		}
		if(!pos8.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())){
			return -1; 
		}
		return 1; 
				
			
	}
	

	protected void swap(int position, int whiteSpace) {
		// TODO Auto-generated method stub
		GridView gridview = (GridView) findViewById(R.id.gridview);
		ImageView current = (ImageView) gridview.getChildAt(position);
		ImageView white = (ImageView) gridview.getChildAt(whiteSpace);
		
		if(current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece1).getConstantState())){
			white.setImageResource(R.drawable.piece1);
		}
		else if (current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece2).getConstantState())){
			white.setImageResource(R.drawable.piece2);
		}
		else if (current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece3).getConstantState())){
			white.setImageResource(R.drawable.piece3);
		}
		else if (current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece4).getConstantState())){
			white.setImageResource(R.drawable.piece4);
		}
		else if (current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece5).getConstantState())){
			white.setImageResource(R.drawable.piece5);
		}
		else if (current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece6).getConstantState())){
			white.setImageResource(R.drawable.piece6);
		}
		else if (current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece7).getConstantState())){
			white.setImageResource(R.drawable.piece7);
		}
		else if (current.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.piece8).getConstantState())){
			white.setImageResource(R.drawable.piece8);
		}
		
		current.setImageResource(R.drawable.white);

	}

	protected int whiteSpaceDetected(int position) {
		// TODO Auto-generated method stub
		GridView gridview = (GridView) findViewById(R.id.gridview);
		
		//UP 
		if(position-3 >= 0) {
			int newPosition = position-3; 
			ImageView white = (ImageView) gridview.getChildAt(newPosition);
			if (white.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())){
				return newPosition; 
			}
		}
		
		//DOWN
		if(position+3 < 9) {
			int newPosition = position+3; 
			ImageView white = (ImageView) gridview.getChildAt(newPosition);
			if (white.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())){
				return newPosition; 
			}
		}
		
		//FOR MOSTRIGHT COLUMN (TO CHEKC LEFT)
		if ((position+1)%3 == 0 && position < 9){			
			int newPosition = position-1; 
			ImageView white = (ImageView) gridview.getChildAt(newPosition);
			if (white.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())){
				return newPosition; 
			}
		}
		
		//FOR MOSTLEFT COLUMN (TO CHECK RIGHT)
		if ((position%3) == 0 ){
			int newPosition = position+1; 
			ImageView white = (ImageView) gridview.getChildAt(newPosition);
			if (white.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())){
				return newPosition; 
			}
		}
		
		//FOR THE MIDDLE COLUMN (TO CHECK RIGHT/LEFT
		if ((position-1)%3 == 0 && position-1 >=0) {
			//check right
			int newPosition = position+1; 
			ImageView white = (ImageView) gridview.getChildAt(newPosition);
			if (white.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())){
				return newPosition; 
			}
			newPosition = position-1; 
			ImageView white2 = (ImageView) gridview.getChildAt(newPosition);
			if (white2.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())){
				return newPosition; 
			}
		}
			
		
		return -1;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
